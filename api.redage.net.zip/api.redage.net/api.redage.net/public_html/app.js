const imgur = require('imgur')
const clientId = '874894c542bdc5e';
imgur.setClientId(clientId);


var fs = require('fs');
var http = require('http');
var https = require('https');
var privateKey  = fs.readFileSync('sslcert/server.key', 'utf8');
var certificate = fs.readFileSync('sslcert/server.crt', 'utf8');

var credentials = { key: privateKey, cert: certificate};
var express = require('express');
var bodyParser = require('body-parser')
var app = express();

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }))
// parse application/json
app.use(bodyParser.json())

// your express configuration here

app.get('/', function (req, res) {
    res.send('Hello World')
})

app.get('/save', function (req, res) {
    console.log("save 1");
    if (req && req.body && req.body.base64image) {
        console.log("save 2");
        imgur
            .uploadBase64(req.body.base64image)
            .then((json) => {
                console.log("save 3");
                res.send(JSON.stringify({link: json.link.toString()}));
                console.log("save 5");
            })
            .catch((err) => {
                console.log("save 4");
                res.send(JSON.stringify({error: err.message}));
            });
    } else {
        res.send(JSON.stringify({error: "Ошибка ебать"}))
    }
})


var httpServer = http.createServer(app);
var httpsServer = https.createServer(credentials, app);

httpServer.listen(8080, () => {
    console.log("http сервер запущен")
});
httpsServer.listen(8443, () => {
    console.log("https сервер запущен")
});




